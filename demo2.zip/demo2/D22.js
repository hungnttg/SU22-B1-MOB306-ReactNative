import React,{useState} from "react";
import {Text,View,TextInput} from 'react-native';
import D23PropCon from "./D23PropCon";

const AProps = (props) =>{
    return(
        <TextInput style={{borderBottomWidth:1,}}
        // cho phép nhập liệu và lưu vào props
            {...props}
            editable
            maxLength={100}
        />
    );
}
const AState = () =>{
    //khai báo và sử dụng state
    const [giaTri,hamThayDoiGiaTri] = useState('');
    return(
        <View>
            {/* goi props */}
            <AProps
                // khi thay đổi text thì gọi hàm thay đổi giá trị
                onChangeText = {text => hamThayDoiGiaTri(text)}
                //truyền vào giá trị
                value={giaTri}
            />
            <Text>Giá trị mới của text là: {giaTri}</Text>
            {/* Cách 2 - gọi component con và truyền giá trị cho component con */}
            <D23PropCon TenNguoi = {giaTri} />
        </View>
    );
}
export default AState;