import React, { Component } from "react";
import {Text,View} from 'react-native';
export default class D21 extends React.Component{
    //1. Khai báo vùng chứa biến trong contructor
    constructor(props)
    {
        super(props);
        //khai báo biến ở đây
        this.state = {
            text: "click vao toi",
            dem: 0,
        }
    }
    //2. Định nghĩa hàm
    updateText()
    {
        //thay đổi giá trị của biến dem và biến text
        this.setState((preState) =>{
            return {
                dem:  preState.dem+1,
                text: 'ban vua click lan thu ',
            }
        });
    }
    //3. hiển thị
    render()
    {
        return(
            <View>
                <Text
                    //4. Xử lý sự kiện khi click vào text
                    onPress={()=> this.updateText()}
                >
                    {/* 5. gọi biến qua state */}
                    {this.state.text} : {this.state.dem}
                </Text>
            </View>
        );
    }

}