import React,{useState} from "react";
import {Text,TextInput,View} from 'react-native';
const D24 = () =>{
    //khai bao bien hoTen va ham setHoTen
    const [hoTen,setHoTen] = useState('');
    return(
        <View>
            <TextInput
                placeholder="Xin moi ban nhap ho ten"
                onChangeText={hoTen => setHoTen(hoTen)}
                defaultValue={hoTen}
            />
            <Text>Ten ban vua nhap la: {hoTen}</Text>
        </View>
    );  
}
export default D24;