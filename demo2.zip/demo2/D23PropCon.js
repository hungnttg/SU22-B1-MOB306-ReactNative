import React from "react";
import {Text,View} from 'react-native';
export default class D23PropCon extends React.Component{
    render()
    {
        return(
            <View>
                {/* thành phần con gọi đến props -> lưu dữ dữ liệu nhập từ cha */}
                <Text>Ten doi tuong la: {this.props.TenNguoi}</Text>
            </View>
        );
    }
}