//npm install axios --save
import React from "react";
import {StyleSheet,Text,View,TouchableOpacity} from 'react-native';
import axios from 'axios';
import { TextInput } from "react-native-gesture-handler";
export default class D71 extends React.Component{
    //1. khoi tao
    constructor(){
        super();
        this.state={
            dataSinhVien: [],
        };
    }
    //Su dung Post (de insert du lieu)
    dinhnghiaPost(){
        var url = 'http://10.82.4.56:3000/data';
        axios.post(url,{
            name: this.state.input1,
            age: this.state.input2
        })
        .then((res)=>{
            console.log(res)
        })
        .catch((err)=>{
            console.log(err)
        });
        //reset lai du lieu
        this.state.input1='';
        this.state.input2='';
    }
    //dinh nghia get (su dung select du lieu)
    dinhnghiaGet(){
        var url = 'http://10.82.4.56:3000/data';
        axios.get(url)
        .then((gData)=>{
            console.log(gData.data);
            this.setState({
                dataSinhVien: gData.data,
            });
        });
    }
    render()
    {
        //lay du lieu cho view???
        const dataMySql = this.state.dataSinhVien.map((item,index)=>{
            var arraySinhVien = 
            ['Name: ', item.name, ' va Age: ',item.age].join('  ');
            return <Text key={index}>{arraySinhVien}</Text>
        });
        return(
            <View style={styles.container}>
                <View>
                    <Text>Ket noi React voi Nodejs</Text>
                    <TextInput
                        placeholder="nhap name vao day"
                        onChangeText={(input1)=>this.setState({input1})}
                        value={this.state.input1}
                    />
                    <TextInput
                        placeholder="nhap age vao day"
                        onChangeText={(input2)=>this.setState({input2})}
                        value={this.state.input2}
                    />
                </View>
                {/* ----- */}
                <View>
                    <TouchableOpacity
                        onPress={this.dinhnghiaPost.bind(this)}
                    >
                        Insert
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={this.dinhnghiaGet.bind(this)}
                    >
                        Select
                    </TouchableOpacity>
                </View>
                {/* --------- */}
                <View>
                    {dataMySql}
                </View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor:'orange',
        alignItems:'center',
        justifyContent:'center',
    }
});