//cai dat cac thu vien express, mysql, body-parser, cors
//npm install express --save
//npm install mysql --save
//npm install body-parser --save
//npm install cors --save
const express = require('express');
const bodyparser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');
//
const app = express();//tao dt moi
app.use(bodyparser.json());//su dung json de chuyen du lieu
app.use(cors());//su dung thu vien cors
//ket noi
const db = mysql.createConnection({
        host: '37.59.55.185',
		user: 'ZsPCk3T1Uu',
		password: 'nwHLKJsGGx',
		port: 3306,
		database:'ZsPCk3T1Uu'
});
db.connect();
//select
app.get('/data',(req,res)=>{
    var sql = "select * from sinhvien";
    db.query(sql,(err,kq)=>{
        if(err) throw err;
        console.log(kq);
        res.send(kq);//tra ket qua ve cho react
    });
});
//insert
app.post('/data',(req,res)=>{
    console.log(req.body);
    var data = {name: req.body.name,age: req.body.age};
    var sql = 'insert into sinhvien set ?';
    db.query(sql,data,(err,kq)=>{
        if(err) throw err;
        console.log(kq);
        //gui ket qua cho react
        res.send({
            status:"Them thanh cong",
            no: null,
            name: req.body.name,
            age: req.body.age
        });
    });
});
//chay 
app.listen(3000,'10.82.4.56',()=>{
    console.log("Server dang chay o cong 3000")
});
