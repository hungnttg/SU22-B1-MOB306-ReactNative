import React from "react";
import {StyleSheet,View,Text,Button,TextInput,TouchableOpacity} from 'react-native';
export default class D31 extends React.Component{
    //2. Viet cac ham xu ly
    //2.1. Khai bao bien
    constructor()
    {
        super();
        this.operations = ['DEL','+','-','*','/'];//khai bao bien dieu khien
        this.state = {
            resultText: "",//bien chua ket qua nhap lieu
            calculationText:"",//chua ket qua tinh toan
        }
    }
    //2.2 Cac ham xu ly
    _onPressButton(text)//ham xu ly khi click vao button
    {
        if(text=="=")//khi click vao dau = thi ta tra ve ket qua tinh toan
        {
            //tinh toan
            return this.calculationResult(this.state.resultText);
        }
        //cap nhat bieu thuc len ket qua nhap lieu
        this.setState({
            resultText: this.state.resultText+text,
        });
    }
    //dinh nghia ham calculationResult
    calculationResult()
    {
        const text = this.state.resultText;//ket qua nhap lieu chuyen vao bien text
        //cap nhat trang thai
        this.setState({
            calculationText: eval(text),//ham tinh toan gia tri bieu thuc
        });
    }
    // dinh nghia ham xu ly su kien
    operate(operation)
    {
        switch(operation)
        {
            case 'DEL':
                //tach chuoi thanh cac thanh phan nho
                let text = this.state.resultText.split('');
                text.pop();//bo di 1 thanh phan cuoi cung
                //cap nhat lai trang thai
                this.setState({
                    resultText: text.join(''),//noi lai chuoi da cat
                });
                break;
            case '+':
            case '-':
            case '*':
            case '/':
                this.setState({
                    resultText: this.state.resultText+operation,//them phep tinh vao ket qua
                });
                break;
        }
    }
    //3. Viet giao dien 
    render()
    {
        let rows = [];
        let nums = [[1,2,3],[4,5,6],[7,8,9],['.','0','=']];
        for(let i=0;i<4;i++)
        {
            let row = [];
            for(let j=0;j<3;j++)
            {
                //dua cac gia tri vao hang (dua con so)
                row.push(
                    <TouchableOpacity
                        style = {styles.btn}
                        key={nums[i][j]}
                        onPress={()=> this._onPressButton(nums[i][j])}>
                    <Text style={styles.btnText}>{nums[i][j]}</Text>            
                    </TouchableOpacity>
                );
            }
            //dua row vao rows => tap hop cac hang
            rows.push(
                <View style={styles.row} key={i}>
                    {row}
                </View>
                );
        }
        //------
        //dua phep tinh vao bang tinh
        let ops = [];
        for(let i=0;i<5;i++)
        {
            ops.push(
                <TouchableOpacity
                    style = {styles.btn}
                    key={this.operations[i]} 
                    onPress={()=>this.operate(this.operations[i])}
                    >
                    <Text style={styles.btnText}>{this.operations[i]}</Text>
                </TouchableOpacity>
            );
        }
        return(
            <View style={styles.container}>
                <View style={styles.result}>
                    <Text style={styles.resultText}>
                        {this.state.resultText}
                    </Text>
                </View> 
                  {/* -------------- */}
                <View style = {styles.calculation}>
                    <Text style={styles.calculationText}>
                        {this.state.calculationText}
                    </Text>
                </View>
                {/* ---------------- */}
                <View style={styles.buttons}>
                    <View style={styles.numbers}>
                        {rows}
                    </View>
                    <View style={styles.operations}>
                        {ops}
                    </View>
                </View>
            </View>
        );
    }
}
// B1 - Viet CSS
const styles = StyleSheet.create({
    container:{
        flex:1,
    },
    //----------------------chia theo cot (flexDirection: column)
    result:{
        flex:2,
        backgroundColor:'green',
        alignItems:'flex-end',
    },
    calculation:{
        flex:1,
        backgroundColor:'yellow',
        justifyContent:'center',
        alignItems:'flex-end',
    },
    buttons: {
        flex:7,
        flexDirection:'row',
    },
    //-------------chia theo hang (flexDirection: row)
    numbers: {
        flex:3,
        backgroundColor:'green',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    operations: {
        flex:1,
        backgroundColor:'blue',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    //----------------dinh dang cac text o trong (chu y: khong dung flex)
    resultText: {
        fontSize:28,
        paddingRight:10,
        backgroundColor:'white',
    },
    calculationText:{
        fontSize:32,
        paddingRight:10,
        color:'orange',
    },
    //-----------dinh dang cac button

    btn: {
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    btnText: {
        fontSize:30,
        paddingRight:10,
        color:'black',
    },
    //----------cac dong (chua number)
    row:{
        flexDirection:'row',
        flex:1,
        justifyContent:'space-around',
        alignItems:'stretch',
    }
});