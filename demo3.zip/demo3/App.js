import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import D21 from './demo2/D21';
import AState from './demo2/D22';
import D24 from './demo2/D24';
import D31 from './demo3/D31';
export default function App() {
  return (
     <D31/>
    // <View style={styles.container}>
    //   {/* --------------Demo2------------------ */}
    //   {/* <Text>Thay doi thong bao! lan 2</Text> */}
    //   {/* <D21/> */}
    //   {/* <AState/> */}
    //   {/* <D24/> */}
    //   {/* <D31/> */}
    //   <StatusBar style="auto" />
    //</View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
