//1. Import thu vien
import React from "react";
import {Text,View} from 'react-native';
//2. Dinh nghia ham
const Demo12 = () => {
    return(
        <View>
            <Text>Day la cach dung Ham</Text>
        </View>
    );
}
export default Demo12;
//3. Export ham