//1.import thu vien
import React from "react";
import {Text,View} from 'react-native';
//2. Dinh nghia class
class Demo11 extends React.Component{
    //ham ket xuat du lieu
    render()
    {
        //tra ve ket qua
        return(
            <View>
                <Text>Day la ung dung su dung Class</Text>
            </View>
        );
    }
}
//3. Export
export default Demo11;
