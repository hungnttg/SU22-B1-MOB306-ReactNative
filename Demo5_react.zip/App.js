import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Demo11 from './demo1/demo11';
import Demo12 from './demo1/demo12';
import D21 from './demo2/D21';
import D24 from './demo2/D24';
import AState from './demo2/D22';
import D31 from './demo3/D31';
import D32 from './demo3/D32';
import D41 from './demo3/D41';
import D42 from './demo3/D42';
import D43 from './demo3/D43';
 import LoadAll from './demo5/LoadAll';
//import LoadAll from './demo51/LoadAll';
export default function App() {
  return (
    <LoadAll/>
      // <D43/>
    // <D42/>
    // <D32/>
    // <View style={styles.container}>
    //   {/* ---------------------------Demo1, Demo2------------- */}
    //   {/* <Text>Sua bang tiengviet!</Text> */}
    //   {/* <Demo11/> */}
    //   {/* <Demo12/> */}
    //   {/* <D21/> */}
    //   {/* <D24/> */}
    //   <AState/>
    //   <StatusBar style="auto" />
    // </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
