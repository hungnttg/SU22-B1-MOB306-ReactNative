//đọc dữ liệu sử dụng API (CÁCH VIẾT FUNC)
//useEffect: sử dụng để kết nối với server
import React,{useEffect,useState} from "react";
import {Text,View,FlatList} from 'react-native';
const D61 = () =>{
    //1.khai báo state
    const [data, setData] = useState([]);
    //2.dọc dữ liệu từ server
    useEffect(()=>{
        fetch('https://hungnttg.github.io/movies.json')//link lay du lieu
        .then((response) => response.json())//dữ liệu chuyển sang dạng json
        .then((json)=>setData(json.movies))//chuyển json thành đối tượng
        .catch((error)=>console.error(error));//bắt lỗi
    },[]);
    //3.hiển thị dữ liệu
    return(
        <View>
            <FlatList
                data={data}
                renderItem={({item})=>(<Text>{item.id} - {item.title} - {item.releaseYear}</Text>)}
            />
        </View>
    );
}
export default D61;