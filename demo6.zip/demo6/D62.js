import React from "react";
import {FlatList,Text,View} from 'react-native';
export default class D62 extends React.Component{
    constructor()
    {
        super();
        //1.khai bao bien
        this.state = {
            data: [],//mảng data
        };
        //2. đọc dữ liệu
        fetch('https://hungnttg.github.io/movies.json')//link lay du lieu
        .then((response) => response.json())//dữ liệu chuyển sang dạng json
        .then((json)=>this.setState({data: json.movies}))//chuyển json thành đối tượng
        .catch((error)=>console.error(error));//bắt lỗi
    }
    render(){
        const {data} = this.state;
        return(
            <View>
                <FlatList
                    data={data}
                    renderItem={({item})=>(<Text>{item.id} - {item.title} - {item.releaseYear}</Text>)}
                />
            </View>
        );
    }
    
    
}
