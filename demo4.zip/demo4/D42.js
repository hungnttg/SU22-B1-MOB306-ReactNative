import React,{useState} from "react";
import {Text,View, TextInput,StyleSheet} from 'react-native';
const TinhTong = (a,b) =>{
    return Number(a)+Number(b);
}
const D42 = () =>{
    const [a,setA] = useState('');
    const [b,setB] = useState('');
    const [c,setC] = useState('');
    return(
        <View style={styles.container}>
                <View style={styles.phan1}>
                    <TextInput style={styles.txt} placeholder="nhap he so a"
                        value={a}
                        onChangeText={tx=>setA(tx)}
                    />
                </View>
                {/* --------- */}
                <View style={styles.phan2}>
                <TextInput style={styles.txt} placeholder="nhap he so b"
                        value={b}
                        onChangeText={tx=>setB(tx)}
                    />
                </View>
                
                {/* --------- */}
                <View style={styles.phan4}>

                </View>
                {/* --------- */}
                <View style={styles.phan5}>
                    <Text style={styles.txt}>Ket qua theo function:---    
                        {TinhTong(a,b)}
                    </Text>
                </View>
                {/* --------- */}
            </View>
    );
}
export default D42;

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column',
        
    },
    phan1: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan2: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan3: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan4: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan5: {
        flex:6,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    txt:{
        fontSize: 30,
        color:'orange',
        fontStyle:'normal',
    }
});