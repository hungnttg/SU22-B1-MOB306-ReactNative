import React,{useState} from "react";
import {Text,View,StyleSheet, TextInput} from 'react-native';
const _tinhTong = (x,y) =>{
    return Number(x)+Number(y);
}
const D42 = () =>{
    const [a,setA] = useState();
    const [b,setB] = useState();
    return(
        <View style={styles.container}>
            <View style={styles.phan1}>
                <TextInput
                    style = {styles.chu}
                    value={a}
                    onChangeText={t => setA(t)} />
            </View>
            {/* ----- */}
            <View style={styles.phan2}>
                <TextInput
                    style = {styles.chu}
                    value={b}
                    onChangeText={t => setB(t)} />
            </View>
            {/* --- */}
            <View style={styles.phan3}>
            </View>
            {/* --- */}
            <View style={styles.phan4}>
                <Text style={styles.chu}>Tong la------:{_tinhTong(a,b)}</Text>
            </View>
        </View>
    );
}
export default D42;
const styles = StyleSheet.create({
    chu:{
        fontSize:30,
        color:'red',
    },
    container:{
        flex:1,
        flexDirection:'column'
    },
    phan1:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan2:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan3:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan4:{
        flex:7,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
});