import React from "react";
import {Text,View,TextInput,StyleSheet} from 'react-native';
export default class D43 extends React.Component{
    //1. khai bao bien, hang
    constructor()
    {
        super();
        //khai bao bien, hang o day
        this.thongbao="";
        //khai bao trang thai(state) o day
        this.state={
            a:0,
            b:0,
            c:0,
        }
    }
    //2. dinh nghia ham
    _setA(t){
        this.setState({
            a:t,
        });
    }
    _setB(t){
        this.setState({
            b:t,
        });
    }
    _setC(t){
        this.setState({
            c:t,
        });
    }
    _giaiPTB2(a,b,c)
    {
       let delta = b*b-4*a*c;
       if(delta<0)
       {
           this.thongbao="Phuong trinh vo nghiem";
           
       }
       else if(delta==0)
       {
           let x = -b/(2*a);
           this.thongbao = "PT co nghiem kep: x= "+x;
           
       }
       else
       {
           let x1 = (-b+Math.sqrt(delta))/(2*a);
           let x2 = (-b-Math.sqrt(delta))/(2*a);
           this.thongbao ="PT co 2 nghiem x1="+x1+"; x2="+x2;
       }
       return this.thongbao;
    }
    //3. giao dien
    render(){
        return(
            <View style={styles.container}>
                <View style={styles.phan1}>
                    <TextInput style={styles.chu}
                        value={this.state.a}
                        onChangeText={(txt) => this._setA(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan2}>
                <TextInput style={styles.chu}
                        value={this.state.b}
                        onChangeText={(txt) => this._setB(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan3}>
                <TextInput style={styles.chu}
                        value={this.state.c}
                        onChangeText={(txt) => this._setC(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan4}>
                    <Text style={styles.chu}>Tong la: 
                    {this._giaiPTB2(this.state.a,this.state.b,this.state.c)}</Text>
                </View>
                {/* ----- */}
            </View>
        );
    }

}
const styles = StyleSheet.create({
    chu:{
        fontSize:30,
        color:'red',
    },
    container:{
        flex:1,
        flexDirection:'column'
    },
    phan1:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan2:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan3:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan4:{
        flex:7,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
});