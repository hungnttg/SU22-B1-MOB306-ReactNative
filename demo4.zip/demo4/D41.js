import React from "react";
import {Text,View,TextInput,StyleSheet} from 'react-native';
export default class D41 extends React.Component{
    //1. khai bao bien, hang
    constructor()
    {
        super();
        //khai bao hang o day
        this.state={
            a:0,
            b:0,
            c:0,
        }
    }
    //2. dinh nghia ham
    _setA(t){
        this.setState({
            a:t,
        });
    }
    _setB(t){
        this.setState({
            b:t,
        });
    }
    _setC(t){
        this.setState({
            c:t,
        });
    }
    _tinhTong(x,y,z)
    {
        return Number(x)+Number(y)+Number(z);
    }
    //3. giao dien
    render(){
        return(
            <View style={styles.container}>
                <View style={styles.phan1}>
                    <TextInput style={styles.chu}
                        value={this.state.a}
                        onChangeText={(txt) => this._setA(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan2}>
                <TextInput style={styles.chu}
                        value={this.state.b}
                        onChangeText={(txt) => this._setB(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan3}>
                <TextInput style={styles.chu}
                        value={this.state.c}
                        onChangeText={(txt) => this._setC(txt)}
                    />
                </View>
                {/* ----- */}
                <View style={styles.phan4}>
                    <Text style={styles.chu}>Tong la: {this._tinhTong(this.state.a,this.state.b,this.state.c)}</Text>
                </View>
                {/* ----- */}
            </View>
        );
    }

}
const styles = StyleSheet.create({
    chu:{
        fontSize:30,
        color:'red',
    },
    container:{
        flex:1,
        flexDirection:'column'
    },
    phan1:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan2:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan3:{
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan4:{
        flex:7,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
});