import React from "react";
import {Text,View,TextInput,TouchableOpacity,StyleSheet} from 'react-native';
export default class D41 extends React.Component{
    //1. khai bao bien, hang
    constructor(){
        super();
        //khai bao hang

        //khai bao bien
        this.state={
            a: 0,
            b: 0,
            c: 0,
            x1: 0,
            x2: 0,
            thongbao:'',
        }
    }
    //2. dinh nghia ham
    _setHeSoA(t)
    {
        this.setState({
            a: t,
        });
    }
    _setHeSoB(t)
    {
        this.setState({
            b: t,
        });
    }
    _setHeSoC(t)
    {
        this.setState({
            c: t,
        });
    }
    _setThongBao(tb)
    {
        this.setState({
            thongbao: tb,
        });
    }
    _giaiPhuongTrinh(a,b,c)
    {
        // let delta = b*b-4*a*c;
        // if(delta<0)
        // {
        //     this.setState({
               
        //     });
        // }  
        
        return Number(a)+Number(b)+Number(c);
        
    }
    //3.giao dien
    render()
    {
        return(
            <View style={styles.container}>
                <View style={styles.phan1}>
                    <TextInput style={styles.txt} placeholder="nhap he so a"
                        value={this.state.a}
                        onChangeText={(text) => this._setHeSoA(text)}
                    />
                </View>
                {/* --------- */}
                <View style={styles.phan2}>
                <TextInput style={styles.txt} placeholder="nhap he so b"
                        value={this.state.b}
                        onChangeText={(text) => this._setHeSoB(text)}
                    />
                </View>
                {/* --------- */}
                <View style={styles.phan3}>
                <TextInput style={styles.txt} placeholder="nhap he so c"
                        value={this.state.c}
                        onChangeText={(text) => this._setHeSoC(text)}
                    />
                </View>
                {/* --------- */}
                <View style={styles.phan4}>

                </View>
                {/* --------- */}
                <View style={styles.phan5}>
                    <Text style={styles.txt}>Ket qua: 
                        {this._giaiPhuongTrinh(this.state.a,this.state.b,this.state.c)} 
                    </Text>
                </View>
                {/* --------- */}
            </View>
        );
    }

}
const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column',
        
    },
    phan1: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan2: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan3: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    phan4: {
        flex:1,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'yellow',
    },
    phan5: {
        flex:6,
        alignItems:'stretch',
        justifyContent:'center',
        backgroundColor:'green',
    },
    txt:{
        fontSize: 30,
        color:'orange',
        fontStyle:'normal',
    }
});